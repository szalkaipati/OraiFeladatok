const canvas =document.getElementById('canvas');
const c = canvas.getContext('2d');
const pont =document.getElementById('pont');
console.log(pont)

canvas.width=innerWidth;
canvas.height=innerHeight;




class Szel{
    static width=40
    static height=40
    constructor({position,image}) {
        this.position=position;
        this.width=40;
        this.height=40;
        this.image=image;
    };

    rajz(){
        c.drawImage(this.image, this.position.x, this.position.y)
    }
};




class Jatekos{
    constructor({position,velocity}){
        this.position=position;
        this.velocity=velocity;
        this.radius=15;
    }

    rajz(){
        c.beginPath()
        c.arc(this.position.x,this.position.y,this.radius,0,Math.PI*2)
        c.fillStyle='yellow';
        c.fill();
        c.closePath()
    }




   fejl(){
        this.rajz()
        this.position.x+=this.velocity.x
        this.position.y+=this.velocity.y
    }
}

class Ghost{
  constructor({position,velocity,color='red'}){
      this.position=position;
      this.velocity=velocity;
      this.radius=15;
      this.color=color
  }

  rajz(){
      c.beginPath()
      c.arc(this.position.x,this.position.y,this.radius,0,Math.PI*2)
      c.fillStyle=this.color;
      c.fill();
      c.closePath()
  }




 fejl(){
      this.rajz()
      this.position.x+=this.velocity.x
      this.position.y+=this.velocity.y
  }
}

class Pellet{
  constructor({position }){
      this.position=position;
      this.radius=3;
  }

  rajz(){
      c.beginPath()
      c.arc(this.position.x,this.position.y,this.radius,0,Math.PI*2)
      c.fillStyle='yellow';
      c.fill();
      c.closePath()
  }
}


const terkep = [
    ['1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-', '-','-', '-','2'],
    ['|', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '|'],
    ['|', '.', 'b', '.', '[', '7', ']', '.', 'b', '.', '.', '5', '.', '.', '.', '.', '|'],
    ['|', '.', '.', '.', '.', '_', '.', '.', '.', '.', '.', '|', '.', '.', '.', '.', '|'],
    ['|', '.', '[', ']', '.', '.', '.', '[', ']', '.', '.', '|', '.', '.', '.', '.', '|'],
    ['|', '.', '.', '.', '.', ' ', '.', '.', '.', '.',  '.', '_', '.', '.', '.', '.','|'],
    ['|', '.', 'b', '.', '[', ' ', ' ', ' ', ']', '.', '.', '.', '.', '.', '.', '.', '|'],
    ['|', '.', '.', '.', '.', '-', '-', '-', '.', '.', '.', '.', '.', '.', '.', '.', '|'],
    ['|', '.', '[', ']', '.', '.', '.', '[', ']', '.', '.', '.', '.', '.', '.', '.', '|'],
    ['|', '.', '.', '.', '.', '^', '.', '.', '.', '.',  '.', '.', '.', '.', '.', '.','|'],
    ['|', '.', 'b', '.', '[', '5', ']', '.', 'b', '.',  '.', '.', '.', '.', '.', '.','|'],
    ['|', '.', '.', '.', '.', '.', '.', '.', '.', 'p',  '.', '.', '.', '.', '.', '.','|'],
    ['4', '-', '-', '-', '-', '-', '-', '-', '-', '-',  '-', '-', '-', '-', '-', '-','3']
  ]
  
function createImage(src) {
  const image = new Image()
  image.src=src
  return image
}   



const pellets=[]
const szelek=[]
const ghost=[
  new Ghost({
    position:{
      x:Szel.width *9+ Szel.width/2,
      y:Szel.height+Szel.height/2
    },
    velocity:{
      x:0,
      y:0
    }
  })
]
const jatekos=new Jatekos({
    position:{
        x:Szel.width+Szel.width/2,
        y:Szel.height+Szel.height/2
    },

    velocity:{
        x:0,
        y:0
    }
});




const keys={

    w:{
        pressed:false
    },

    a:{
        pressed:false
    },

    s:{
        pressed:false
    },

    d:{
        pressed:false
    }
}




let utolso=''
let pt=0

terkep.forEach((row, i) => {
  row.forEach((szimbolum, j) => {
    switch (szimbolum) {
      case '-':
        szelek.push(
          new Szel({
            position: {
              x: Szel.width * j,
              y: Szel.height * i
            },
            image: createImage('./kepek/pipeHorizontal.png')
          })
          )
          break
        case '|':
          szelek.push(
            new Szel({
              position: {
                x: Szel.width * j,
                y: Szel.height * i
              },
              image: createImage('./kepek/pipeVertical.png')
            })
          )
          break
        case '1':
          szelek.push(
            new Szel({
              position: {
                x: Szel.width * j,
                y: Szel.height * i
              },
              image: createImage('./kepek/pipeCorner1.png')
            })
          )
          break
        case '2':
          szelek.push(
            new Szel({
              position: {
                x: Szel.width * j,
                y: Szel.height * i
              },
              image: createImage('./kepek/pipeCorner2.png')
            })
          )
          break
        case '3':
          szelek.push(
            new Szel({
              position: {
                x: Szel.width * j,
                y: Szel.height * i
              },
              image: createImage('./kepek/pipeCorner3.png')
            })
          )
          break
        case '4':
          szelek.push(
            new Szel({
              position: {
                x: Szel.width * j,
                y: Szel.height * i
              },
              image: createImage('./kepek/pipeCorner4.png')
            })
          )
          break
        case 'b':
          szelek.push(
            new Szel({
              position: {
                x: Szel.width * j,
                y: Szel.height * i
              },
              image: createImage('./kepek/block.png')
            })
          )
          break
        case '[':
          szelek.push(
            new Szel({
              position: {
                x: j * Szel.width,
                y: i * Szel.height
              },
              image: createImage('./kepek/capLeft.png')
            })
          )
          break
        case ']':
          szelek.push(
            new Szel({
              position: {
                x: j * Szel.width,
                y: i * Szel.height
              },
              image: createImage('./kepek/capRight.png')
            })
          )
          break
        case '_':
          szelek.push(
            new Szel({
              position: {
                x: j * Szel.width,
                y: i * Szel.height
              },
              image: createImage('./kepek/capBottom.png')
            })
          )
          break
        case '^':
          szelek.push(
            new Szel({
              position: {
                x: j * Szel.width,
                y: i * Szel.height
              },
              image: createImage('./kepek/capTop.png')
            })
          )
          break
        case '+':
          szelek.push(
            new Szel({
              position: {
                x: j * Szel.width,
                y: i * Szel.height
              },
              image: createImage('./kepek/pipeCross.png')
            })
          )
          break
        case '5':
          szelek.push(
            new Szel({
              position: {
                x: j * Szel.width,
                y: i * Szel.height
              },
              color: 'blue',
              image: createImage('./kepek/pipeConnectorTop.png')
            })
          )
          break
        case '6':
          szelek.push(
            new Szel({
              position: {
                x: j * Szel.width,
                y: i * Szel.height
              },
              color: 'blue',
              image: createImage('./kepek/pipeConnectorRight.png')
            })
          )
          break
        case '7':
          szelek.push(
            new Szel({
              position: {
                x: j * Szel.width,
                y: i * Szel.height
              },
              color: 'blue',
              image: createImage('./kepek/pipeConnectorBottom.png')
            })
          )
          break
        case '8':
          szelek.push(
            new Szel({
              position: {
                x: j * Szel.width,
                y: i * Szel.height
              },
              image: createImage('./kepek/pipeConnectorLeft.png')
            })
          )
          break
      case '.':
        pellets.push(
          new Pellet({
              position: {
              x: j * Szel.width + Szel.width / 2,
              y: i * Szel.height + Szel.height / 2
              }
          })
        )
        break 
    }
  })
})

function hozzaer({kor,kocka}){
    return (kor.position.y-kor.radius+kor.velocity.y
        <=kocka.position.y+kocka.height 
        && kor.position.x+kor.radius+kor.velocity.x
        >=kocka.position.x 
        && kor.position.y+kor.radius+kor.velocity.y>=kocka.position.y && kor.position.x-kor.radius+kor.velocity.x
        <=kocka.position.x+kocka.width)
}

function mozg(){
    requestAnimationFrame(mozg)
    c.clearRect(0,0,canvas.width, canvas.height)

    if(keys.w.pressed && utolso==='w'){
        for(let i=0; i<szelek.length;i++){
            const szel=szelek[i]
        if (hozzaer({
            kor:{...jatekos,velocity:{
                x:0,
                y:-5
            }},
            kocka:szel})
            ){
                jatekos.velocity.y=0
                break
                
            }  
        else{
            jatekos.velocity.y=-5
        } 
    }
    }
    else if(keys.a.pressed && utolso==='a'){
        for(let i=0; i<szelek.length;i++){
            const szel=szelek[i]
        if (hozzaer({
            kor:{...jatekos,velocity:{
                x:-5,
                y:0
            }},
            kocka:szel})
            ){
                jatekos.velocity.x=0
                break
                
            }  
        else{
            jatekos.velocity.x=-5 
        } 
    }      
    }
    else if(keys.s.pressed && utolso==='s'){
        for(let i=0; i<szelek.length;i++){
            const szel=szelek[i]
        if (hozzaer({
            kor:{...jatekos,velocity:{
                x:0,
                y:5
            }},
            kocka:szel})
            ){
                jatekos.velocity.y=0
                break
                
            }  
        else{
            jatekos.velocity.y=5
        } 
    }
    }
    else if(keys.d.pressed && utolso==='d'){
        for(let i=0; i<szelek.length;i++){
            const szel=szelek[i]
        if (hozzaer({
            kor:{...jatekos,velocity:{
                x:5,
                y:0
            }},
            kocka:szel})
            ){
                jatekos.velocity.x=0 
                break
                
            }  
        else{
            jatekos.velocity.x=5
        } 
    }
    }
    
    for (let i=pellets.length-1; 0<i; i--){

      const pellet=pellets[i]
      pellet.rajz()
      if (Math.hypot(pellet.position.x-jatekos.position.x,pellet.position.y-jatekos.position.y)<pellet.radius+jatekos.radius){
      console.log("erintkezik")
      pellets.splice(i,1)
      pt+=1
      pont.innerHTML=pt
    }    
    }

    szelek.forEach((szel)=>{ 
        szel.rajz()

        /*  */
        if (hozzaer({kor:jatekos,
        kocka:szel})) {
            console.log("asdasdasd")
            jatekos.velocity.x=0
            jatekos.velocity.y=0
        }
})
jatekos.fejl();
ghost.forEach(ghost=>{
  ghost.fejl()
  const collisions =[]
  szelek.forEach(szel=>{
    if (hozzaer({
      kor:{...jatekos,velocity:{
          x:5,
          y:0
      }},
      kocka:szel})
      )
  {
    collisions.push('jobb')
  }})
})



/*if(keys.w.pressed && utolso==='w'){
    jatekos.velocity.y=-5
}
else if(keys.a.pressed && utolso==='a'){
    jatekos.velocity.x=-5
}
else if(keys.s.pressed && utolso==='s'){
    jatekos.velocity.y=5
}
else if(keys.d.pressed && utolso==='d'){
    jatekos.velocity.x=5
}*/
}



mozg()

//szelek.forEach((szel)=>{ szel.rajz()})
//jatekos.fejl();



window.addEventListener('keydown',({key})=>{
    //console.log(key)
    switch(key){
        case 'w':
            keys.w.pressed=true
            utolso='w'
        break
        case 'a':
            keys.a.pressed=true
            utolso='a'
        break
        case 's':
            keys.s.pressed=true
            utolso='s'
        break
        case 'd':
            keys.d.pressed=true
            utolso='d'
        break
    }
    console.log(keys.s.pressed)
})




window.addEventListener('keyup',({key})=>{
    //console.log(key)
    switch(key){
        case 'w':
            keys.w.pressed=false
        break
        case 'a':
            keys.a.pressed=false
        break
        case 's':
            keys.s.pressed=false
        break
        case 'd':
            keys.d.pressed=false
        break
    }
    console.log(keys.s.pressed)
})