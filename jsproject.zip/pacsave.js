const canvas =document.getElementById('canvas');
const c = canvas.getContext('2d');



canvas.width=innerWidth;
canvas.height=innerHeight;

class Szel{
    constructor({position}) {
        this.position=position;
        this.width=50;
        this.height=50;
    };

    rajz(){
        c.fillStyle=' blue';
        c.fillRect(this.position.x, this.position.y, this.width, this.height);
        //c.fillRect(10, 10, 50, 50);
    }
};
const terkep=[
    ['-','-','-','-','-','-','-','-'],
    ['-',' ',' ',' ',' ',' ',' ','-'],
    ['-',' ',' ',' ',' ',' ',' ','-'],
    ['-',' ',' ',' ',' ',' ',' ','-'],
    ['-','-','-','-','-','-','-','-']
]
const szelek=[]

terkep.forEach((row,i)=>{
    row.forEach((szimbolum,j) =>{
        switch(szimbolum){
            case '-':
                szelek.push(
                    new Szel({
                    position: {
                        x:50*j,
                        y:50*i
                    }
                 })
                )
                break
        }
    })
})

szelek.forEach((szel)=>{ szel.rajz()})