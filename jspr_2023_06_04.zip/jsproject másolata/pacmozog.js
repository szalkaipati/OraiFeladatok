const canvas =document.getElementById('canvas');
const c = canvas.getContext('2d');

canvas.width=innerWidth;
canvas.height=innerHeight;




class Szel{
    static width=50
    static height=50
    constructor({position}) {
        this.position=position;
        this.width=50;
        this.height=50;
    };

    rajz(){
        c.fillStyle=' blue';
        c.fillRect(this.position.x, this.position.y, this.width, this.height);
        //c.fillRect(10, 10, 50, 50);
    }
};




class Jatekos{
    constructor({position,velocity}){
        this.position=position;
        this.velocity=velocity;
        this.radius=20;
    }

    rajz(){
        c.beginPath()
        c.arc(this.position.x,this.position.y,this.radius,0,Math.PI*2)
        c.fillStyle='yellow';
        c.fill();
        c.closePath()
    }




   fejl(){
        this.rajz()
        this.position.x+=this.velocity.x
        this.position.y+=this.velocity.y
    }
}




const terkep=[
    ['-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-'],
    ['-',' ','-',' ',' ',' ','-',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','-',' ',' ',' ','-'],
    ['-',' ','-',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','-'],
    ['-',' ','-',' ','-','-','-','-',' ',' ','-',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','-'],
    ['-',' ','-',' ','-',' ',' ','-',' ',' ','-',' ','-',' ',' ',' ',' ','-','-','-','-','-'],
    ['-',' ',' ',' ','-',' ',' ','-',' ',' ','-',' ','-',' ',' ',' ',' ',' ',' ',' ',' ','-'],
    ['-',' ',' ',' ','-',' ',' ','-',' ',' ','-',' ','-',' ',' ','-',' ',' ',' ',' ',' ','-'],
    ['-',' ','-','-','-',' ',' ','-',' ',' ','-',' ','-',' ','-','-',' ',' ',' ',' ',' ','-'],
    ['-',' ',' ',' ',' ',' ',' ','-',' ',' ','-',' ',' ',' ',' ',' ','-','-','-',' ',' ','-'],
    ['-',' ',' ',' ','-','-','-','-',' ',' ','-',' ',' ',' ',' ',' ',' ',' ','-',' ',' ','-'],
    ['-',' ',' ',' ','-',' ',' ',' ',' ',' ','-',' ',' ',' ',' ',' ','-',' ','-',' ',' ','-'],
    ['-','-','-',' ','-','-','-','-',' ',' ','-',' ',' ','-',' ',' ','-','-','-',' ',' ','-'],
    ['-',' ',' ',' ',' ',' ',' ',' ',' ',' ','-',' ',' ','-',' ',' ',' ',' ',' ',' ',' ','-'],
    ['-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-']

]

const szelek=[]
const jatekos=new Jatekos({
    position:{
        x:Szel.width+Szel.width/2,
        y:Szel.height+Szel.height/2
    },

    velocity:{
        x:0,
        y:0
    }
});




const keys={

    w:{
        pressed:false
    },

    a:{
        pressed:false
    },

    s:{
        pressed:false
    },

    d:{
        pressed:false
    }
}




let utolso=''
terkep.forEach((row,i)=>{
    row.forEach((szimbolum,j) =>{
        switch(szimbolum){
            case '-':
                szelek.push(
                    new Szel({
                    position: {
                        x:Szel.width*j,
                        y:Szel.height*i
                    }
                 })
                )

                break
        }
    })
})



function mozg(){
    requestAnimationFrame(mozg)
    c.clearRect(0,0,canvas.width, canvas.height)
    szelek.forEach((szel)=>{ szel.rajz()})
jatekos.fejl();
jatekos.velocity.x=0
jatekos.velocity.y=0



if(keys.w.pressed && utolso==='w'){
    jatekos.velocity.y=-5
}
else if(keys.a.pressed && utolso==='a'){
    jatekos.velocity.x=-5
}
else if(keys.s.pressed && utolso==='s'){
    jatekos.velocity.y=5
}
else if(keys.d.pressed && utolso==='d'){
    jatekos.velocity.x=5
}
}



mozg()

//szelek.forEach((szel)=>{ szel.rajz()})
//jatekos.fejl();



window.addEventListener('keydown',({key})=>{
    //console.log(key)
    switch(key){
        case 'w':
            keys.w.pressed=true
            utolso='w'
        break
        case 'a':
            keys.a.pressed=true
            utolso='a'
        break
        case 's':
            keys.s.pressed=true
            utolso='s'
        break
        case 'd':
            keys.d.pressed=true
            utolso='d'
        break
    }
    console.log(keys.s.pressed)
})




window.addEventListener('keyup',({key})=>{
    //console.log(key)
    switch(key){
        case 'w':
            keys.w.pressed=false
        break
        case 'a':
            keys.a.pressed=false
        break
        case 's':
            keys.s.pressed=false
        break
        case 'd':
            keys.d.pressed=false
        break
    }
    console.log(keys.s.pressed)
})