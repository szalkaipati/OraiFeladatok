const canvas =document.getElementById('canvas');
const c = canvas.getContext('2d');

canvas.width=innerWidth;
canvas.height=innerHeight;




class Szel{
    static width=50
    static height=50
    constructor({position}) {
        this.position=position;
        this.width=50;
        this.height=50;
    };

    rajz(){
        c.fillStyle=' blue';
        c.fillRect(this.position.x, this.position.y, this.width, this.height);
        //c.fillRect(10, 10, 50, 50);
    }
};




class Jatekos{
    constructor({position,velocity}){
        this.position=position;
        this.velocity=velocity;
        this.radius=20;
    }

    rajz(){
        c.beginPath()
        c.arc(this.position.x,this.position.y,this.radius,0,Math.PI*2)
        c.fillStyle='yellow';
        c.fill();
        c.closePath()
    }




   fejl(){
        this.rajz()
        this.position.x+=this.velocity.x
        this.position.y+=this.velocity.y
    }
}




const terkep = [
    ['1', '-', '-', '-', '-', '-', '-', '-', '-', '-', '2'],
    ['|', '.', '.', '.', '.', '.', '.', '.', '.', '.', '|'],
    ['|', '.', 'b', '.', '[', '7', ']', '.', 'b', '.', '|'],
    ['|', '.', '.', '.', '.', '_', '.', '.', '.', '.', '|'],
    ['|', '.', '[', ']', '.', '.', '.', '[', ']', '.', '|'],
    ['|', '.', '.', '.', '.', '^', '.', '.', '.', '.', '|'],
    ['|', '.', 'b', '.', '[', '+', ']', '.', 'b', '.', '|'],
    ['|', '.', '.', '.', '.', '_', '.', '.', '.', '.', '|'],
    ['|', '.', '[', ']', '.', '.', '.', '[', ']', '.', '|'],
    ['|', '.', '.', '.', '.', '^', '.', '.', '.', '.', '|'],
    ['|', '.', 'b', '.', '[', '5', ']', '.', 'b', '.', '|'],
    ['|', '.', '.', '.', '.', '.', '.', '.', '.', 'p', '|'],
    ['4', '-', '-', '-', '-', '-', '-', '-', '-', '-', '3']
  ]
  
  map.forEach((row, i) => {
    row.forEach((symbol, j) => {
      switch (symbol) {
        case '-':
          boundaries.push(
            new Boundary({
              position: {
                x: Boundary.width * j,
                y: Boundary.height * i
              },
              image: createImage('./kepek/pipeHorizontal.png')
            })
          )
          break
        case '|':
          boundaries.push(
            new Boundary({
              position: {
                x: Boundary.width * j,
                y: Boundary.height * i
              },
              image: createImage('./kepek/pipeVertical.png')
            })
          )
          break
        case '1':
          boundaries.push(
            new Boundary({
              position: {
                x: Boundary.width * j,
                y: Boundary.height * i
              },
              image: createImage('./kepek/pipeCorner1.png')
            })
          )
          break
        case '2':
          boundaries.push(
            new Boundary({
              position: {
                x: Boundary.width * j,
                y: Boundary.height * i
              },
              image: createImage('./kepek/pipeCorner2.png')
            })
          )
          break
        case '3':
          boundaries.push(
            new Boundary({
              position: {
                x: Boundary.width * j,
                y: Boundary.height * i
              },
              image: createImage('./kepek/pipeCorner3.png')
            })
          )
          break
        case '4':
          boundaries.push(
            new Boundary({
              position: {
                x: Boundary.width * j,
                y: Boundary.height * i
              },
              image: createImage('./kepek/pipeCorner4.png')
            })
          )
          break
        case 'b':
          boundaries.push(
            new Boundary({
              position: {
                x: Boundary.width * j,
                y: Boundary.height * i
              },
              image: createImage('./kepek/teljes.png')
            })
          )
          break
        case '[':
          boundaries.push(
            new Boundary({
              position: {
                x: j * Boundary.width,
                y: i * Boundary.height
              },
              image: createImage('./kepek/capLeft.png')
            })
          )
          break
        case ']':
          boundaries.push(
            new Boundary({
              position: {
                x: j * Boundary.width,
                y: i * Boundary.height
              },
              image: createImage('./kepek/capRight.png')
            })
          )
          break
        case '_':
          boundaries.push(
            new Boundary({
              position: {
                x: j * Boundary.width,
                y: i * Boundary.height
              },
              image: createImage('./kepek/capBottom.png')
            })
          )
          break
        case '^':
          boundaries.push(
            new Boundary({
              position: {
                x: j * Boundary.width,
                y: i * Boundary.height
              },
              image: createImage('./kepek/capTop.png')
            })
          )
          break
        case '+':
          boundaries.push(
            new Boundary({
              position: {
                x: j * Boundary.width,
                y: i * Boundary.height
              },
              image: createImage('./kepek/pipeCross.png')
            })
          )
          break
        case '5':
          boundaries.push(
            new Boundary({
              position: {
                x: j * Boundary.width,
                y: i * Boundary.height
              },
              color: 'blue',
              image: createImage('./kepek/pipeConnectorTop.png')
            })
          )
          break
        case '6':
          boundaries.push(
            new Boundary({
              position: {
                x: j * Boundary.width,
                y: i * Boundary.height
              },
              color: 'blue',
              image: createImage('./kepek/pipeConnectorRight.png')
            })
          )
          break
        case '7':
          boundaries.push(
            new Boundary({
              position: {
                x: j * Boundary.width,
                y: i * Boundary.height
              },
              color: 'blue',
              image: createImage('./kepek/pipeConnectorBottom.png')
            })
          )
          break
        case '8':
          boundaries.push(
            new Boundary({
              position: {
                x: j * Boundary.width,
                y: i * Boundary.height
              },
              image: createImage('./kepek/pipeConnectorLeft.png')
            })
          )
          break
        case '.':
          pellets.push(
            new Pellet({
              position: {
                x: j * Boundary.width + Boundary.width / 2,
                y: i * Boundary.height + Boundary.height / 2
              }
            })
          )
          break
      }
    })
  })

const szelek=[]
const jatekos=new Jatekos({
    position:{
        x:Szel.width+Szel.width/2,
        y:Szel.height+Szel.height/2
    },

    velocity:{
        x:0,
        y:0
    }
});




const keys={

    w:{
        pressed:false
    },

    a:{
        pressed:false
    },

    s:{
        pressed:false
    },

    d:{
        pressed:false
    }
}




let utolso=''
terkep.forEach((row,i)=>{
    row.forEach((szimbolum,j) =>{
        switch(szimbolum){
            case '-':
                szelek.push(
                    new Szel({
                    position: {
                        x:Szel.width*j,
                        y:Szel.height*i
                    }
                 })
                )

                break
        }
    })
})


function hozzaer({kor,kocka}){
    return (kor.position.y-kor.radius+kor.velocity.y
        <=kocka.position.y+kocka.height 
        && kor.position.x+kor.radius+kor.velocity.x
        >=kocka.position.x 
        && kor.position.y+kor.radius+kor.velocity.y>=kocka.position.y && kor.position.x-kor.radius+kor.velocity.x
        <=kocka.position.x+kocka.width)
}

function mozg(){
    requestAnimationFrame(mozg)
    c.clearRect(0,0,canvas.width, canvas.height)

    if(keys.w.pressed && utolso==='w'){
        for(let i=0; i<szelek.length;i++){
            const szel=szelek[i]
        if (hozzaer({
            kor:{...jatekos,velocity:{
                x:0,
                y:-5
            }},
            kocka:szel})
            ){
                jatekos.velocity.y=0
                break
                
            }  
        else{
            jatekos.velocity.y=-5
        } 
    }
    }
    else if(keys.a.pressed && utolso==='a'){
        for(let i=0; i<szelek.length;i++){
            const szel=szelek[i]
        if (hozzaer({
            kor:{...jatekos,velocity:{
                x:-5,
                y:0
            }},
            kocka:szel})
            ){
                jatekos.velocity.x=0
                break
                
            }  
        else{
            jatekos.velocity.x=-5 
        } 
    }      
        //jatekos.velocity.x=-5
    }
    else if(keys.s.pressed && utolso==='s'){
        for(let i=0; i<szelek.length;i++){
            const szel=szelek[i]
        if (hozzaer({
            kor:{...jatekos,velocity:{
                x:0,
                y:5
            }},
            kocka:szel})
            ){
                jatekos.velocity.y=0
                break
                
            }  
        else{
            jatekos.velocity.y=5
        } 
    }
    }
    else if(keys.d.pressed && utolso==='d'){
        for(let i=0; i<szelek.length;i++){
            const szel=szelek[i]
        if (hozzaer({
            kor:{...jatekos,velocity:{
                x:5,
                y:0
            }},
            kocka:szel})
            ){
                jatekos.velocity.x=0 
                break
                
            }  
        else{
            jatekos.velocity.x=5
        } 
    }
        
        //jatekos.velocity.x=5
    }
    
    szelek.forEach((szel)=>{ 
        szel.rajz()
        if (hozzaer({kor:jatekos,
        kocka:szel})) {
            console.log("asdasdasd")
            jatekos.velocity.x=0
            jatekos.velocity.y=0
        }
})
jatekos.fejl();
/*jatekos.velocity.x=0
jatekos.velocity.y=0*/



/*if(keys.w.pressed && utolso==='w'){
    jatekos.velocity.y=-5
}
else if(keys.a.pressed && utolso==='a'){
    jatekos.velocity.x=-5
}
else if(keys.s.pressed && utolso==='s'){
    jatekos.velocity.y=5
}
else if(keys.d.pressed && utolso==='d'){
    jatekos.velocity.x=5
}*/
}



mozg()

//szelek.forEach((szel)=>{ szel.rajz()})
//jatekos.fejl();



window.addEventListener('keydown',({key})=>{
    //console.log(key)
    switch(key){
        case 'w':
            keys.w.pressed=true
            utolso='w'
        break
        case 'a':
            keys.a.pressed=true
            utolso='a'
        break
        case 's':
            keys.s.pressed=true
            utolso='s'
        break
        case 'd':
            keys.d.pressed=true
            utolso='d'
        break
    }
    console.log(keys.s.pressed)
})




window.addEventListener('keyup',({key})=>{
    //console.log(key)
    switch(key){
        case 'w':
            keys.w.pressed=false
        break
        case 'a':
            keys.a.pressed=false
        break
        case 's':
            keys.s.pressed=false
        break
        case 'd':
            keys.d.pressed=false
        break
    }
    console.log(keys.s.pressed)
})