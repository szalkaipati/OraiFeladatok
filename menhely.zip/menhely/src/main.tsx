import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import Nyitooldal from './components/nyitooldal.tsx'
import { createBrowserRouter } from 'react-router-dom'
import Kutyak from './components/kutyak.tsx'
import UjKutyak from './components/ujkutya.tsx'

const router= createBrowserRouter([
  {
  path:'/',
  element: <Nyitooldal/>
  },
  {
    path:'/',
    element: <Kutyak/>
    },
    {
      path:'/',
      element: <UjKutyak/>
      }
])

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    
  </StrictMode>,
)
