import { useEffect, useState } from "react"
import { Kutya } from "../kutya.modell";

export default function Nyitooldal(){
    const [kutyakData, setKutyakData]=useState<Kutya>([])

    const getKutyak=async()=>{
        try{
            const result=await fetch("http://localhost:5000/kutyak");
            const data=result.json();
            //console.log(data);
            setKutyakData(await data);
        }
        catch(error){
            console.log(error)
        }
    }

    useEffect(()=>{getKutyak},[])

    const deleteKutya=async(kutyaId:number)=>{
        try{
            const result=await fetch("http://localhost:5000/kutyak",{
            headers:{
                "Content-Type":"application/json;character-TF-8"
            },
            method:"DELETE",
            body:JSON.stringify({"id":kutyaId})
        });
            if(result.status==200){
                setKutyakData(kutyakData.filter(kutya=>kutya.id!=kutyaId));
            }
        }

        catch(error){
            console.log(error)
        }
    }

    return (
        <div className="conatiner">
        <header className="text-center">
            <div className="row my-3">
            <h1>Örökbefogadható kutyák</h1>
            </div>
            </header>
            <main>
                <table className="table table-stripped">
                    <thead>
                        <tr>
                            <th>Fénykép</th>
                            <th>Név</th>
                            <th>Fajta</th>
                            <th>Nem</th>
                            <th>Életkor</th>
                            <th>Törlés</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            kutyakData.map(kutya : Kutya=>{
                                return(
                                    <tr key={kutya.id}>
                                        <td><img src={kutya.kepUrl} alt="kep" height="100" /></td>
                                        <td>{kutya.nev}</td>
                                        <td>{kutya.fajta}</td>
                                        <td className={kutya.nem?"text-succes":"text-danger"} >{kutya.nem?"Kan":"Szuka" }</td>
                                        <td>{kutya.eletkor}</td>
                                        <td><button className="btn btn-danger" onClick={()=>{deleteKutya{Kutya.id}}}> Törlés</button></td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
            </main>
        </div>
    )
}