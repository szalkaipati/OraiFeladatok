import { useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function UjKutyak(){
    const inputNev=useRef({}); //lehet null is
    const inputFajta=useRef(null);
    const inputNem=useRef(null);
    const inputEletkor=useRef(null);
    const inputKep=useRef(null);
    const navigate=useNavigate();
    const [errorState, useErrorState]=useState()
    const addNewKutya=async()=>{
        try{
            let eletkor;
            if(inputEletkor.current.value*1<0){
                eletkor=0
            }
            else if (inputEletkor.current.value*1>20){
                eletkor=20
            }
            else
            {
                eletkor=inputEletkor.current.value*1
            }
            const result=await fetch("http://localhost:5000/kutyak",{
            headers:{
                "Content-Type":"application/json;character-TF-8"
            },
            method:"POST",
            body:JSON.stringify({"nev":inputNev.current.value,
                "fajta":inputFajta.current.value,
                "nem":inputNem.current.checked?true:false,
                "eletkor":inputEletkor.current.value*1,
                "kepUrl":inputKep.current.value
            })
        });
        if(result.status==200){
            navigate("/kutyak")
        }
            console.log(result)
        }

        catch(error){
            console.log(error)
        }
    }

    return (
        <div className="container">
            <header className="text-center">
                <div className="row my-3">
                    <h1>Új kutya felvétele</h1>
                </div>
            </header>

            <main>
                <div className="row">
                    <div className="col-md-3"></div>
                    <div className="col-md-6"></div>
                </div>
                <form action="">
                    <label htmlFor="nev" className="form-label mt-2">Kutya neve</label>
                    <input ref={inputNev} type="text" id="nev" className="form-control"/>

                    <label htmlFor="fajta" className="form-label mt-2">Kutya fajtája</label>
                    <input ref={inputFajta} type="text" id="fajta" className="form-control"/>

                    <div className="mt-3">Kutya neme</div>
                    <input type="radio" id="nem-szuka" name="nem" className="form-check-input mt-2 ms-3"/>
                    <label htmlFor="nem-szuka" className="form-check-label mt-1 ms-2">Szuka</label>
                    <br />
                    <input ref={inputNem} type="radio" id="nem-kan" name="nem" className="form-check-input"/>
                    <label htmlFor="nem-kan" className="form-check-label mt-1 ms-2">Kan</label>
                    <br />

                    <label htmlFor="eletkor" className="form-label mt-2">Kutya életkora</label>
                    <input ref={inputEletkor} type="number" id="eletkor" className="form-control" min="0" max="20"/>

                    <label htmlFor="kep" className="form-label mt-2">Fénykép a kutyáról</label>
                    <input ref={inputKep} type="text" id="kep" className="form-control"/>
                    <div className="row text-center mt-4">
                        <div className="col">
                            <button className="btn btn-primary" onClick={addNewKutya}>Küldés</button>
                        </div>
                    </div>

                    <div className="alert alert-danger" role="alert">
                        {errorStatus.status+" - "+ errprState.statuserror}
                    </div>
                </form>

            </main>
        </div>
    )
    
}